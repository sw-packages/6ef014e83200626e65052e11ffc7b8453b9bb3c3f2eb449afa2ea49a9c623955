//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Weta Digital, Ltd and Contributors to the OpenEXR Project.
//

#ifndef TESTFUTUREPROOFING_H_
#define TESTFUTUREPROOFING_H_

#include <string>
void testFutureProofing  (const std::string & tempDir);

#endif
